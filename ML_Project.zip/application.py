from flask import Flask, request, render_template
import numpy as np
import pandas as pd
import os

from sklearn.preprocessing import StandardScaler
from src.Pipeline.predict_pipeline import CustomData, PredictPipeline

application = Flask(__name__)

app = application 

#Route for a homepage

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predictdata', methods=['GET', 'POST'])
def predict_datapoint():
    if request.method == 'GET':
        return render_template('home.html')
    else:
        data=CustomData(
            gender=request.form.get('gender'),
            race_ethnicity=request.form.get('ethnicity'),
            parental_level_of_education=request.form.get('parental_level_of_education'),
            lunch=request.form.get('lunch'),
            test_preparation_course=request.form.get('test_preparation_course'),
            reading_score=float(request.form.get('reading_score')),
            writing_score=float(request.form.get('writing_score'))

        )
        pred_df=data.get_data_as_dataframe()
        print(pred_df)
        print("Before Prediction")

        predict_pipeline=PredictPipeline()
        print("Mid Prediction")
        results=predict_pipeline.predict(pred_df)
        print("after Prediction")
        
        model_scores = {
        "Linear Regression": 0.88,
        "Random Forest": 0.84,
        "Decision Tree": 0.73,
        "Gradient Boosting": 0.85,
        "XGBRegressor": 0.86,
        "CatBoosting Regressor": 0.85,
        "AdaBoost Regressor": 0.82
    }

        return render_template(
            'home.html',
            results=results[0],
            model_scores=model_scores
        )
    


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
